/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaformas;
import java.util.Scanner;

/**
 *
 * @author Usuario1
 */
public class ProgramaJavaFormas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner entrada=new Scanner(System.in);
        Triangulo nuevoTriangulo=new Triangulo("Negro");
        Cuadrado nuevoCuadrado=new Cuadrado("Rojo");
        Circulo nuevoCirculo=new Circulo("Verde");
        Linea nuevaLinea =new Linea();
        
        nuevoTriangulo.Dibujar();
        System.out.println();
        System.out.printf("El color del Triangulo es :");
        System.out.printf(nuevoTriangulo.obtenerColor());
        System.out.println();
        
        nuevoCuadrado.Dibujar();
        System.out.println();
        System.out.printf("El color del Cuadrado es :");
        System.out.printf(nuevoCuadrado.obtenerColor());
        System.out.println();
        
        nuevoCirculo.Dibujar();
        System.out.println();
        System.out.printf("El color del Circulo es :");
        System.out.printf(nuevoCirculo.obtenerColor());
        System.out.println();
        
        nuevaLinea.Dibujar();
        System.out.println();
        System.out.printf("El color de la linea es :");
        System.out.printf(nuevaLinea.obtenerColor());
        System.out.println();
        
    }
    
}
