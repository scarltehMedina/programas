/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaformas;

/**
 *
 * @author Usuario1
 */
public class Cuadrado extends Formas {
    private double Area;
    private double base;
    private double altura;
    
    
    public Cuadrado(String _color)
    {
        super(_color);
        this.Color=_color;
    }
    public Cuadrado()
    {
        this.Color=Color;
    }
     public void establecerBase(double _base)
    {
        base=_base;
    }
     public double establecerBase()
    {
       return base;
    }
     
     public void establecerAltura(double _altura)
    {
        altura=_altura;
    }
    public double obtenerAltura()
    {
       return altura;
    }
     public double CalcularArea()
     {
         Area=(double)(base*altura)/2;
         return Area;
     }
       @Override
    public void Dibujar()
    {
        System.out.printf("Cuadrado");
    }
    
    @Override
    public void establecerColor(String _color)
    {
        this.Color=_color;
    }
    @Override
    public String obtenerColor()
    {
        return Color;
    }
}
