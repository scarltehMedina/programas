/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaformas;

/**
 *
 * @author Usuario1
 */
public abstract class Formas {
    protected String Color;
   public Formas(String _Color)
   {
       this.Color=_Color;
   }
   public Formas()
   {
       this.Color="Blanco";
   }
   public abstract void Dibujar();
   public abstract void establecerColor(String _color);
   public abstract String obtenerColor();
}
