/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaformas;

/**
 *
 * @author Usuario1
 */
public class Circulo extends Formas {
    private double Radio;
    public Circulo(String _color)
    {
       super(_color);
       this.Color=_color;
    }
     public Circulo()
    {
       this.Color=Color;
    }
    public void establecerRadio(double _radio)
    {
        Radio=_radio;
    }
    public double CalcularRadio()
    {
        return Radio*Radio*3.14151617;
    }
    @Override
    public void Dibujar()
    {
        System.out.printf("Circulo");
    }
    
    @Override
    public void establecerColor(String _color)
    {
        this.Color=_color;
    }
     @Override
    public String obtenerColor()
    {
        return Color;
    }
}
