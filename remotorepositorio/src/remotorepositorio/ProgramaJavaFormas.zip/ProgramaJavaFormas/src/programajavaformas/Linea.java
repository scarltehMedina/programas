/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaformas;

/**
 *
 * @author Usuario1
 */
public class Linea extends Formas {
    private double Largo;
    public Linea(String _color)
    {
        super(_color);
        this.Color=_color;
    }
     public Linea()
    {
        this.Color=Color;
    }
    public void establecerLargo(double _largo)
    {
        Largo=_largo;
    }
    public double obtenerLargo()
    {
        return Largo;
    }
      @Override
    public void Dibujar()
    {
        System.out.printf("Linea");
    }
    
    @Override
    public void establecerColor(String _color)
    {
        this.Color=_color;
    }
     @Override
    public String obtenerColor()
    {
        return Color;
    }
}
