/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajava2;
import java.util.Scanner;
/**
 *
 * @author Usuario1
 */
public class ProgramaJava2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero1;
        int numero2;
        int suma;
        int resta;
        int multiplicacion;
        int division;
        int residuo;
        
        Scanner entrada=new Scanner(System.in);
        
        System.out.printf("Ingrese el numero 1  :");
        numero1=entrada.nextInt();
        System.out.printf("Ingrese el numero 2  :");
        numero2=entrada.nextInt();
        suma=numero1+numero2;
        System.out.printf("La suma de %d + %d es %d", numero1,numero2,suma);
        System.out.println();
        
        resta=numero1-numero2;
        System.out.printf("La resta de %d - %d es %d", numero1,numero2,resta);
        System.out.println();
        resta=numero2-numero1;
        System.out.printf("La resta de %d - %d es %d", numero2,numero1,resta);
        System.out.println();
        
        if(numero2 !=0)
        {
           division=numero1/numero2;
           System.out.printf("La division entera de %d / %d es %d", numero1,numero2,division);
           System.out.println();  
        }
        else
        {
           System.out.printf("La division entera de %d / %d no es posible", numero1,numero2);  
           System.out.printf("Segundo numero ingresado: %d", numero2);
           System.out.println(); 
           System.out.printf("La division entre 0 no es posible");
           System.out.println(); 
        }
        if(numero1!=0)
        {
          division=numero2/numero1;
          System.out.printf("La division entera de %d / %d es %d", numero2,numero1,division);
          System.out.println(); 
        }
        else
        {
           System.out.printf("La division entera de %d / %d no es posible\n", numero2,numero1);  
           System.out.printf("Primer numero ingresado: %d", numero1);
           System.out.println(); 
           System.out.printf("La division entre 0 no es posible");
           System.out.println(); 
        }
        
        if(numero1!=0 && numero2!=0)
        {
           residuo= numero1%numero2;
           System.out.printf("El residuo de %d entre %d es %d", numero1,numero2,residuo);
           System.out.println();
           residuo= numero2%numero1;
           System.out.printf("El residuo de %d entre %d es %d", numero2,numero1,residuo);
           System.out.println(); 
        }
        else
        {
           System.out.printf("No podemos extraer el residuo se ingreso un 0 verifique %d y %d",numero1,numero2);
           System.out.println(); 
        }
       
        
    }
    
}
