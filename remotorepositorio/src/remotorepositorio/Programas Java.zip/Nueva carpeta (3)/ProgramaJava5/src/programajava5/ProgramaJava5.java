/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajava5;
import java.util.Scanner;
/**
 *
 * @author Usuario1
 */
public class ProgramaJava5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String [][] datos= new String[5][4];
        Scanner entrada= new Scanner(System.in);
        for(int fila=0; fila<5;fila++)
        {
            for(int columna=0;columna<1;columna++)
            {
                System.out.printf("Ingrese Nombre: ");
                datos[fila][0]=entrada.next();
                System.out.println();
                System.out.printf("Ingrese Apellido: ");
                datos[fila][1]=entrada.next();
                System.out.println();
                System.out.printf("Ingrese Carrera: ");
                datos[fila][2]=entrada.next();
                System.out.println();
                System.out.printf("Ingrese Lugar de trabajo: ");
                datos[fila][3]=entrada.next();
                System.out.println();
            }
        }
         System.out.printf("\tNombre\t\tApellido\tCarrera\t\tLugar de Trabajo: ");
         System.out.println();
          for(int fila=0; fila<5;fila++)
        {
            for(int columna=0;columna<4;columna++)
            {
                System.out.printf("\t%s\t",datos[fila][columna]);
            }
              System.out.println();
        }
    }
    
}
