/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajava3;

/**
 *
 * @author Usuario1
 */
public class ProgramaJava3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int M=6;
        int T=1;
        int K=-10;
        if(M>T)
        {
           System.out.printf("!Verdadero¡, %d si es mayor que %d", M,T);
           System.out.println();
        }
        if(T/K==-5)
        {
          //No se hara nada, la condicion es falsa se ejecuta el else
        }
        else
        {
           System.out.printf("!Falso¡ el resultado es diferente %d  %d", T,K);
           System.out.println();
        }
        if(M+T==7 || M-T==5)
        {
            System.out.printf("!Verdadero¡, %d  %d", M,T); 
            System.out.println();
        }
    }
    
}
