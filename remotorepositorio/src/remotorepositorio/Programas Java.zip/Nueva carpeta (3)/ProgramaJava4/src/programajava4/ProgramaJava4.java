/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajava4;
import java.util.Scanner;
/**
 *
 * @author Usuario1
 */
public class ProgramaJava4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String [] comp= new String[10];
        
     public static void main(String[] args) {
         
     }
        String[] comp = new String[10];
        comp[0] = "Norman Gomez";
        comp[1] = "Aylin Maldonado";
        comp[2] = "Cristian Menjivar";
        comp[3] = "Jorge Dubon";       
        comp[4] = "Escarlet Castillo";
        comp[5] = "Jeffre Quintero";
        comp[6] = "Mynor Piota";
        comp[7] = "Enrrique Paz";
        comp[8] = "Gustavo Marquez";
        comp[9] = "Enrrique Paz";

        System.out.println("Nombre 1:" + comp[0]);
        System.out.println("Nombre 2:" + comp[1]);
        System.out.println("Nombre 3:" + comp[2]);
        System.out.println("Nombre 4:" + comp[3]);
        System.out.println("Nombre 5:" + comp[4]);
        System.out.println("Nombre 6:" + comp[5]);
        System.out.println("Nombre 7:" + comp[6]);
        System.out.println("Nombre 8:" + comp[7]);
        System.out.println("Nombre 9:" + comp[8]);
        System.out.println("Nombre 10:" + comp[9]);
    }
    
}


