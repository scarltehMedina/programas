/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajava6;
import java.util.Scanner;
/**
 *
 * @author Usuario1
 */
public class ProgramaJava6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre;
        int nota;
        
        Scanner entrada=new Scanner(System.in);
        System.out.printf("Ingrese el nombre del estudiante: ");
        nombre=entrada.next();
        System.out.println();
        System.out.printf("Ingrese la nota del estudiante: ");
        nota=entrada.nextInt();
        System.out.println();
        if(nota>=70)
        {
          System.out.printf("%s %d Aprobado", nombre,nota);
           System.out.println();
        }
        else
        {
          System.out.printf("%s %d Reprobado", nombre,nota);   
           System.out.println();
        }
    }
    
}
