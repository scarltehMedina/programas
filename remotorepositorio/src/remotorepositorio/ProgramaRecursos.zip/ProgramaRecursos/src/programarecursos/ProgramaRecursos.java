/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package programarecursos;
import java.util.Scanner;

/**
 *
 * @author Usuario1
 */
public class ProgramaRecursos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Recursos miRecurso=new Recursos();
        miRecurso.primerMetodo();
        miRecurso.segundoMetodo();
        
        Scanner entrada=new Scanner(System.in);
        int numero_1;
        int numero_2;
        
        System.out.printf("Ingrese un numero: ");
        numero_1=entrada.nextInt();
        System.out.printf("Ingrese un numero: ");
        numero_2=entrada.nextInt();
        miRecurso.tercerMetodo(numero_1, numero_2);
        
        int numero_ultimo;
        System.out.printf("Ingrese un numero para imprimir lista desde 1: ");
        numero_ultimo=entrada.nextInt();
        miRecurso.cuartoMetodo(numero_ultimo);
        
    }
    
}
