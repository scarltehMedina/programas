/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programarecursos;

/**
 *
 * @author Usuario1
 */
public class Recursos {
    public void  primerMetodo()
    {
        System.out.println("Estoy aprendiendo, pero sere el mejor programador del mundo");
    }
    
    public void segundoMetodo()
    {
        int nota=85;
        System.out.printf("Nota asignada:%d",nota);
      
        if(nota>=70)
        {
            System.out.printf("\nAprobado\n"); 
        }
        else
        {
              System.out.printf("Reprobado");  
        }
    }
    
    public void tercerMetodo(int numero1, int numero2)
    {
        double resultado1,resultado2;
        if(numero1==0 || numero2==0)
        {
            System.out.printf("No es posible la division entre 0");   
        }
        else
        {
            resultado1=(double)numero1/numero2;
            resultado2=(double)numero2/numero1;
            System.out.printf("El resultado de dividir %d entre %d es : %.2f\n", numero1,numero2, resultado1);
            System.out.printf("El resultado de dividir %d entre %d es : %.2f\n", numero2,numero1, resultado2);
        }
    }
    public void cuartoMetodo(int numero_final)
    {
        for(int i=1; i<=numero_final;i++)
        {
            System.out.printf("Numero de lista:%d",i);
            System.out.printf("\n");
        }
    }
}
