/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaencapsulacion;
import java.util.Scanner;
/**
 *
 * @author Usuario1
 */
public class ProgramaJavaEncapsulacion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Inicia primera parte
        Scanner entrada= new Scanner(System.in);
        Ciudadano nuevoCiudadano = new Ciudadano();
        
        System.out.printf("Ingrese el nombre del ciudadano\n");
        nuevoCiudadano.establecerNombre(entrada.next());
        System.out.printf("Ingrese la edad del ciudadano\n");
        nuevoCiudadano.establecerEdad(entrada.nextDouble());
        System.out.printf("Ingrese la experiencia del ciudadano\n");
        nuevoCiudadano.establecerExperiencia(entrada.nextDouble());
        System.out.println();
        System.out.printf("****************************************************");
        System.out.println();
        System.out.printf("****************************************************");
        System.out.println();
        
        System.out.printf("Datos del ciudadano\n");
        System.out.printf("Nombre : ");
        System.out.printf(nuevoCiudadano.obtenerNombre());
        System.out.println();
        System.out.printf("Edad : ");
        System.out.print(nuevoCiudadano.obtenerEdad());
        System.out.println();
        System.out.printf("Experiencia : ");
        System.out.print(nuevoCiudadano.obtenerExperiencia());
        System.out.println();
        //Fin de primera parte
        //***************************************************************************************************
        //Inicia segunda parte
        Honduras verPaisH = new Honduras("Juan Orlando Hernandez", "Honduras");
        Guatemala verPaisG=new Guatemala("Jimmy Morales", "Guatemala");
        ElSalvador verPaisES =new ElSalvador("Nayib Bukele", "El Salvador");
        
        System.out.printf("Presidente: ");
        System.out.printf(verPaisH.obtenerPresidente());
        System.out.println();
        System.out.printf("Pais: ");
        System.out.printf(verPaisH.obtenerPais());
        System.out.println();
        
        System.out.printf("Presidente: ");
        System.out.printf(verPaisG.obtenerPresidente());
        System.out.println();
        System.out.printf("Pais: ");
        System.out.printf(verPaisG.obtenerPais());
        System.out.println();
        
        System.out.printf("Presidente: ");
        System.out.printf(verPaisES.obtenerPresidente());
        System.out.println();
        System.out.printf("Pais: ");
        System.out.printf(verPaisES.obtenerPais());
        System.out.println();
        //Fin de la segunda parte
    }
    
}
