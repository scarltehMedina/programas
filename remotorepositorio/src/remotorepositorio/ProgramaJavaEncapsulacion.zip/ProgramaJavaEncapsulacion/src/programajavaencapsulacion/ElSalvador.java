/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaencapsulacion;

/**
 *
 * @author Usuario1
 */
public class ElSalvador extends Pais{
    public ElSalvador(String _presidente,String _pais)
    {
        super(_presidente,_pais);// El Contructor de la super Clase recibe los parametros
        // Se asignan valores a los atributos heredados de la super Clase
        this.presidente=_presidente; // Asigna el nombre del presidente
        this.pais=_pais;// Asigna el nombre del pais
    }
    @Override
    public String obtenerPresidente()
    {
        return presidente;
    }
    @Override
    public String obtenerPais()
    {
        return pais;
    }
}
