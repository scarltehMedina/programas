/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaencapsulacion;

/**
 *
 * @author Usuario1
 */
public class Ciudadano {
    private String nombreciudadano;
    private double edad;
    double experiencia;
    
    public Ciudadano()
    {
        nombreciudadano="";
        edad=0.0;
        experiencia= 0.0;
    }
    
    public void establecerNombre(String _nombre)
    {
        if(_nombre!="")
        {
           nombreciudadano=_nombre;  
        }
       else
        {
            throw new IllegalArgumentException("Debe proporcionar un nombre");
        }
    }
    public String obtenerNombre()
    {
        return nombreciudadano;
    }
    
    public void establecerEdad(double _edad)
    {
        if(_edad>0)
        {
          edad=_edad;
        }
         else
        {
            throw new IllegalArgumentException("Debe proporcionar edades mayores a 0");
        }
    }
    public double obtenerEdad()
    {
        return edad;
    }
    public void establecerExperiencia(double _experiencia)
    {
        if(_experiencia>=0)
        {
          experiencia=_experiencia;
        }
         else
        {
            throw new IllegalArgumentException("Debe proporcionar experiencia mayor o igual  a 0");
        }
       
    }
    public double obtenerExperiencia()
    {
        return experiencia;
    }
}
