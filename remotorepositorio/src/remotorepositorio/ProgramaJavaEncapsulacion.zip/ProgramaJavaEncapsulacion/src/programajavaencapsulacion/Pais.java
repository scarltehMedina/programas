/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programajavaencapsulacion;

/**
 *
 * @author Usuario1
 */
public abstract class Pais {
    protected String presidente;// Atributo heredado a las clases hijas
    protected String pais;// Atributo heredado a las clases hijas
    public Pais(String _presidente, String _pais)
    {
        presidente=_presidente;
        pais=_pais;
    }
    public abstract String obtenerPais();
   
    public abstract String obtenerPresidente();
}
