/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dell
 */
public class Estudiante {
    
    

String nombre;
String Apellido;
String edad;
String sexo;
String carrera;



public static void main(String[] args) {
    
    Estudiante estudiante = new Estudiante();
    estudiante.nombre = "Scarlett";
    estudiante.Apellido = "Medina";
    estudiante.edad = "19 años";
    estudiante.sexo = "femenino";
    estudiante.carrera = "Ing. Produccion Industrial";
    
    
    System.out.println("Mi nombre es:" + estudiante.nombre);
    System.out.println("Mi apellido es:" + estudiante.Apellido);
    System.out.println("Mi edad es:" + estudiante.edad);
    System.out.println("Mi sexo es:" + estudiante.sexo);
    System.out.println("Estudiante de la carrera:" + estudiante.carrera);
}
}
